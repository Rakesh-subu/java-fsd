package com.mphasis.exception;

//Custom exception class
class CustomException extends Exception {
 public CustomException(String message) {
     super(message);
 }
}

public class ExceptionHandlingExample {
 // Method that throws a checked exception using 'throws' keyword
 public static void methodWithThrows(int number) throws CustomException {
     if (number < 0) {
         throw new CustomException("Number cannot be negative.");
     }
     System.out.println("Number is: " + number);
 }

 // Method that throws an exception using 'throw' keyword
 public static void methodWithThrow(int number) {
     if (number == 0) {
         throw new IllegalArgumentException("Number cannot be zero.");
     }
     System.out.println("Number is: " + number);
 }

 public static void main(String[] args) {
     try {
         // Using methodWithThrows that declares checked exception using 'throws' keyword
         methodWithThrows(-5);
     } catch (CustomException e) {
         System.out.println("Caught CustomException: " + e.getMessage());
     }

     try {
         // Using methodWithThrow that throws an exception using 'throw' keyword
         methodWithThrow(0);
     } catch (IllegalArgumentException e) {
         System.out.println("Caught IllegalArgumentException: " + e.getMessage());
     } finally {
         System.out.println("Inside finally block.");
     }
 }
}

