package com.mphasis.queue;
class SimpleQueue {
    private static final int MAX_SIZE = 100; // Maximum size of the queue
    private int[] queueArray;
    private int front;
    private int rear;

    public SimpleQueue() {
        queueArray = new int[MAX_SIZE];
        front = 0;
        rear = -1; // Initialize rear to -1 to indicate an empty queue
    }

    public void enqueue(int value) {
        if (rear < MAX_SIZE - 1) {
            queueArray[++rear] = value;
            System.out.println("Enqueued: " + value);
        } else {
            System.out.println("Queue is full. Cannot enqueue " + value);
        }
    }

    public void dequeue() {
        if (front <= rear) {
            int dequeuedValue = queueArray[front++];
            System.out.println("Dequeued: " + dequeuedValue);
        } else {
            System.out.println("Queue is empty. Cannot dequeue.");
            // Reset front and rear to their initial positions
            front = 0;
            rear = -1;
        }
    }

    public boolean isEmpty() {
        return front > rear;
    }
}

public class QueueExample {
    public static void main(String[] args) {
        SimpleQueue queue = new SimpleQueue();

        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(3);
        queue.enqueue(4);
        queue.enqueue(5);
        queue.enqueue(6); // Attempting to enqueue an element into a full queue

        while (!queue.isEmpty()) {
            queue.dequeue();
        }

        queue.dequeue(); // Attempting to dequeue from an empty queue
    }
}

