import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseOperations {
  
    private static final String URL = "jdbc:mysql://localhost:3306/";
    private static final String USER = "root";
    private static final String PASSWORD = "rakesh";

    public static void main(String[] args) throws SQLException {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

   
            // Step 1: Establishing a Connection
            connection = DriverManager.getConnection(URL, USER, PASSWORD);

            // Step 2: Creating a Database
            String createDatabase = "CREATE DATABASE IF NOT EXISTS table";
            statement = connection.createStatement();
            statement.executeUpdate(createDatabase);
            System.out.println("Database created successfully.");

            // Step 3: Selecting Data from the Database
            String useDatabase = "USE table";
            statement.executeUpdate(useDatabase);

            String createTable = "CREATE TABLE IF NOT EXISTS users (id INT PRIMARY KEY, name VARCHAR(25))";
            statement.executeUpdate(createTable);

            String insertData = "INSERT INTO users (id, name) VALUES (1, 'rakesh')";
            statement.executeUpdate(insertData);

            String selectDataQuery = "SELECT * FROM users";
            resultSet = statement.executeQuery(selectDataQuery);
            System.out.println("Data from the users table:");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                System.out.println("ID: " + id + ", Name: " + name);
            }

            // Step 4: Dropping the Database
            String dropDatabaseQuery = "DROP DATABASE IF EXISTS mydatabase";
            statement.executeUpdate(dropDatabaseQuery);
            System.out.println("Database dropped successfully.");

       
    }
}
