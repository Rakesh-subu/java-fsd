package com.mphasis.Exponential;

import java.util.Arrays;

public class ExponentialSearch {

    public static int binarySearch(int[] arr, int target, int left, int right) {
        if (right >= left) {
            int mid = left + (right - left) / 2;

            if (arr[mid] == target) {
                return mid;
            }

            if (arr[mid] > target) {
                return binarySearch(arr, target, left, mid - 1);
            }

            return binarySearch(arr, target, mid + 1, right);
        }

        return -1;
    }

    public static int exponentialSearch(int[] arr, int target) {
        int size = arr.length;
        if (arr[0] == target) {
            return 0; // Element found at index 0
        }

        int i = 1;
        while (i < size && arr[i] <= target) {
            i *= 2;
        }

        // Perform binary search in the found range
        return binarySearch(arr, target, i / 2, Math.min(i, size - 1));
    }

    public static void main(String[] args) {
        int[] array = {1, 3, 5, 7, 9, 11, 13, 15};
        int target = 7;
        int result = exponentialSearch(array, target);

        if (result != -1) {
            System.out.println("Element found at index: " + result);
        } else {
            System.out.println("Element not found in the array");
        }
    }
}
