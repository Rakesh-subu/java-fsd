package com.example.demo;


import com.example.demo.FileStorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class FileUploadController {

    @Autowired
    private FileStorageService fileStorageService;

    @PostMapping("/uploadFile")
    public String handleFileUpload(@RequestPart("file") MultipartFile file) {
        fileStorageService.save(file);
        return "redirect:/uploadForm.html?success";
    }
}