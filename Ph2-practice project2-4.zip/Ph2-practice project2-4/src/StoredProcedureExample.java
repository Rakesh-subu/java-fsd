import java.sql.*;

public class StoredProcedureExample {
    private static final String URL = "jdbc:mysql://localhost:3306/mydatabase";
    private static final String USER = "root";
    private static final String PASSWORD = "rakesh";

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            // Calling Stored Procedure
            int userId = 1;
            try (CallableStatement callableStatement = connection.prepareCall("{call GET_USER_BY_ID(?)}")) {
                callableStatement.setInt(1, userId);
                ResultSet resultSet = callableStatement.executeQuery();

                if (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String name = resultSet.getString("name");
                    System.out.println("User ID: " + id + ", Name: " + name);
                } else {
                    System.out.println("User not found for ID: " + userId);
                }
            } catch (SQLException e) {
                handleSQLException(e);
            }
        } catch (SQLException e) {
            handleSQLException(e);
        }
    }

    private static void handleSQLException(SQLException e) {
        System.err.println("SQLException: " + e.getMessage());
        System.err.println("SQLState: " + e.getSQLState());
        System.err.println("VendorError: " + e.getErrorCode());
    }
}
