package com.mphasis.LinearSearch;

import java.util.Scanner;

public class LinearSearchEx {
	
	public static int linerSearch(int arr[],int point)
	{
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==point)
			{
			return i;
			}
			
		}
		return -1;
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of the array:");
		int size=sc.nextInt();
		
		int array[]=new int[size];
		System.out.println("Enter the  elementf the array:");
		for(int i=0;i<size;i++) {
			array[i]=sc.nextInt();}
		 System.out.print("Enter the target element to search for: ");
	        int point = sc.nextInt();
	        int result =linerSearch(array, point);

	        if (result != -1) {
	            System.out.println("Element found at index: " + result);
	        } else {
	            System.out.println("Element not found in the array");
	        }
	}

}
