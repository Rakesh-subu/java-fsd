package com.mphasis.range;

import java.util.Scanner;

public class SumInRange {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Read the number of elements in the array
        System.out.print("Enter the number of elements: ");
        int n = scanner.nextInt();
        
        // Initialize an array of size n
        int[] array = new int[n];
        
        // Read the elements of the array
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            array[i] = scanner.nextInt();
        }
        
        // Read the range L and R
        System.out.print("Enter the value of L (0 <= L <= n-1): ");
        int L = scanner.nextInt();
        
        System.out.print("Enter the value of R (L <= R <= n-1): ");
        int R = scanner.nextInt();
        
        // Calculate the sum of elements in the range of L and R
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += array[i];
        }
        
        // Print the sum
        System.out.println("Sum of elements in the range of L and R: " + sum);
        
        
    }
}
