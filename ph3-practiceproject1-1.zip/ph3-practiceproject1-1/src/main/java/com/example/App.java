package com.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
  public static void main(String[] args) {
	  ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
  	//via class name 
  Airtel airtel=ac.getBean(Airtel.class);
//  //via identifier 
//  //	Airtel airtel=(Airtel) ac.getBean("airtel");
    airtel.dataTypeOfSim();
    airtel.typeOfSim();
    Idea idea=ac.getBean(Idea.class);
//     
	  
      System.out.println(airtel.getSignal());
      
      System.out.println(idea.getSignal());
   
  
     
  }

}
