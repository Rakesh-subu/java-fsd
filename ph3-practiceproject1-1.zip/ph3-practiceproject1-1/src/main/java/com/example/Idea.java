package com.example;

public class Idea implements Sim{
	private String signal; 
	
	public Idea(String signal) {
		super();
		this.signal = signal;
	}
	

	public String getSignal() {
		return signal;
	}


	public void setSignal(String signal) {
		this.signal = signal;
	}


	@Override
	public void typeOfSim() {
		System.out.println("this is an idea sim ");
	}

	@Override
	public void dataTypeOfSim() {
		System.out.println("this supports 4G data ");
		
	}

}

