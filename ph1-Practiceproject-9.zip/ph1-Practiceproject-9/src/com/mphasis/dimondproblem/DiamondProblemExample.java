package com.mphasis.dimondproblem;
//Interface defining a method
interface Animal {
 void sound();
}

//Interfaces inheriting from Animal interface
interface Dog extends Animal {
 void bark();
}

interface Cat extends Animal {
 void meow();
}

//Class implementing both Dog and Cat interfaces
class Pet implements Dog, Cat {
 
 public void sound() {
     System.out.println("Pet makes a sound.");
 }

 
 public void bark() {
     System.out.println("Dog barks.");
 }


 public void meow() {
     System.out.println("Cat meows.");
 }
}

public class DiamondProblemExample {
 public static void main(String[] args) {
     Pet myPet = new Pet();
     myPet.sound(); // Output: Pet makes a sound.
     myPet.bark();  // Output: Dog barks.
     myPet.meow();  // Output: Cat meows.
 }
}

