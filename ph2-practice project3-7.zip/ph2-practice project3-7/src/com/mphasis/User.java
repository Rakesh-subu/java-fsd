package com.mphasis;

import javax.persistence.*;

@Entity
@Table(name = "user")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Long userId;

    @Column(name = "username")
    private String username;

    // Component mapping for Address
    @Embedded
    private Address address;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public User(Long userId, String username, Address address) {
		super();
		this.userId = userId;
		this.username = username;
		this.address = address;
	}

	public User() {
		// TODO Auto-generated constructor stub
	}



	@Override
	public String toString() {
		return "User [userId=" + userId + ", username=" + username + ", address=" + address + "]";
	}

    
}
