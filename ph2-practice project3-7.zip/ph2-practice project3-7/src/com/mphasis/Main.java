package com.mphasis;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

    public static void main(String[] args) {
        // Create SessionFactory
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

        // Open a session
        Session session = sessionFactory.openSession();

        // Begin a transaction
        Transaction transaction = session.beginTransaction();

        // Create a User
        User user = new User();
        user.setUsername("Rakesh");

        // Create an Address
        Address address = new Address();
        address.setStreet("123 Main St");
        address.setCity("Anytown");
        address.setZipcode("12345");

        // Set Address for User
        user.setAddress(address);

        // Save the User (and Address will be saved automatically due to cascading)
        session.save(user);

        // Commit the transaction
        transaction.commit();

        // Close the session
        session.close();

        // Close the SessionFactory (typically done in a shutdown hook)
        sessionFactory.close();
    }
}

