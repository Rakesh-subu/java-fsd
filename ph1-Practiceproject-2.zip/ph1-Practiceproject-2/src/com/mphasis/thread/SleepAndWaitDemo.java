package com.mphasis.thread;

public class SleepAndWaitDemo {

    public static void main(String[] args) {
        Object lock = new Object();

        Thread thread1 = new Thread(new Runnable() {
      
            public void run() {
                synchronized (lock) {
                    System.out.println("Thread 1 is waiting...");
                    try {
                        lock.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    System.out.println("Thread 1 is notified!");
                }
            }
        });

        Thread thread2 = new Thread(new Runnable() {
         
            public void run() {
                synchronized (lock) {
                    System.out.println("Thread 2 is sleeping...");
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    System.out.println("Thread 2 is waking up...");
                    lock.notifyAll();
                }
            }
        });

        thread1.start();
        thread2.start();
    }
}
