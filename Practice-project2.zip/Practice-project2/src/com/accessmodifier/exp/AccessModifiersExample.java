package com.accessmodifier.exp;

public class AccessModifiersExample {
	 public int publicVariable = 10; // Public variable
	    protected int protectedVariable = 20; // Protected variable
	    int defaultVariable = 30; // Default (package-private) variable
	    private int privateVariable = 40; // Private variable

	    // Public constructor
	    public AccessModifiersExample() {
	        System.out.println("Public Constructor");
	    }

	    // Protected method
	    protected void protectedMethod() {
	        System.out.println("Protected Method");
	    }

	    // Default method
	    void defaultMethod() {
	        System.out.println("Default Method");
	    }

	    // Private method
	    private void privateMethod() {
	        System.out.println("Private Method");
	    }

	    // Main method to test access modifiers
	    public static void main(String[] args) {
	        AccessModifiersExample obj = new AccessModifiersExample();
	        System.out.println("Public Variable: " + obj.publicVariable);
	        System.out.println("Protected Variable: " + obj.protectedVariable);
	        System.out.println("Default Variable: " + obj.defaultVariable);
	        System.out.println("Private Variable: " + obj.privateVariable);

	        obj.protectedMethod();
	        obj.defaultMethod();
	        obj.privateMethod();
	    }

}
