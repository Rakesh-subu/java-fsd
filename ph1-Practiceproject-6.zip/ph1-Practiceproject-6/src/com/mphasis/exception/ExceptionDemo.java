package com.mphasis.exception;

public class ExceptionDemo {

    public static void main(String[] args) {
        try {
        	try {
        
            // Code that may throw an exception
            int[] numbers = {1, 2, 3};
            System.out.println(numbers[4]); 
            // This will throw an ArrayIndexOutOfBoundsException
            
           

            // Output the result
        
        } catch (ArrayIndexOutOfBoundsException e) {
            // Handle the exception
            System.out.println("ArrayIndexOutOfBoundsException: " + e.getMessage());
            
            int result = 50/0;
        }
        } catch(ArithmeticException e)
        {
        	 System.out.println("Error: Division by zero is not allowed.");
        }
        finally {
            // Code that is always executed, even if an exception is thrown
            System.out.println("Finally block executed");
        }
    }
}
