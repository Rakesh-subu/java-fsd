package com.mphasis.rotate;

 class RightRotateArray {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}; // Sample array
        int steps = 5; // Number of steps to right rotate

        System.out.println("Original Array:");
        for(int num: array)
        {
        	System.out.println(num+" ");
        }
        System.out.println();
    
    
    //Right rotate the array by 5 steps 
    for(int i=0;i<array.length;i++)
    {
    	//calculate the new index after the roration
    	int newIndex=(i+steps)%array.length;
    	//print the element at the new index
    	
    	System.out.println(array[newIndex]+" ");
    }
    System.out.println("\nArray after right rotation by 5 steps:");
    }
 }