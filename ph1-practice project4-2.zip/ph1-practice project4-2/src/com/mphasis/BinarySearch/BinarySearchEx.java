package com.mphasis.BinarySearch;

public class BinarySearchEx {
	public static int binaryseach(int arr[],int target)
	{
		int first=0;
		
	    int last=arr.length-1;
	    while(first<=last)
	    {
	    	int mid=first+(last-first)/2;
	    	if(arr[mid]==target)
	    	{
	    		return mid;
	    	}
	    	if(arr[mid]<last)
	    	{
	    		first=mid+1;
	    	}
	    	else
	    	{
	    		last=mid-1;
	    	}
	    }
	    return -1;
	}
public static void main(String[] args) {
	 int[] array = {1, 3, 5, 7, 9, 11, 13, 15};
     int target = 7;
     int result = binaryseach(array, target);
     
     if(result !=-1) {
    	 System.out.println("Element found at index: " + result);
} else {
    System.out.println("Element not found in the array");
}
}
}
