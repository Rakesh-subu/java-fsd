package com.mphasis.exception;



public class Demo {
	public static void main(String[] args) {
		try {
		int a=40/0;//exception obj
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("hi learners ");
	}


}
