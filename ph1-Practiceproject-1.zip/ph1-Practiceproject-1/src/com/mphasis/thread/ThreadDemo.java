package com.mphasis.thread;

//Thread class extension
class MyThread extends Thread {
 public void run() {
     for (int i = 1; i <= 5; i++) {
         System.out.println("Thread 1: " + i);
     }
 }
}

//Runnable interface implementation
class MyRunnable implements Runnable {
 public void run() {
     for (int i = 1; i <= 5; i++) {
         System.out.println("Thread 2: " + i);
     }
 }
}

public class ThreadDemo {
 public static void main(String[] args) {
     // Creating threads by extending Thread class
     MyThread thread1 = new MyThread();
     thread1.start(); // Start the first thread

     // Creating threads by implementing Runnable interface
     Thread thread2 = new Thread(new MyRunnable());
     thread2.start(); // Start the second thread

     
     for (int i = 1; i <= 5; i++) {
         System.out.println("Main Thread: " + i);
     }
 }
}
