package com.example;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledIfSystemProperty;

public class ConditionalTests {

    @Test
    void testOnAllSystems() {
        // This test will run on all systems
        assertTrue(true);
    }

    @Test
    @DisabledIfSystemProperty(named = "os.arch", matches = ".*64.*")
    void testDisabledOn64BitSystem() {
        // This test will be disabled on 64-bit systems
        assertTrue(false);
    }

}

