package com.mphasis.doubllylinked;

class Node {
    int data;
    Node next;
    Node prev;

    public Node(int data) {
        this.data = data;
        this.next = null;
        this.prev = null;
    }
}

class DoublyLinkedList {
    Node head;
    Node tail;

    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            // If the list is empty, make the new node the head and tail
            head = newNode;
            tail = newNode;
        } else {
            // Insert the new node at the end of the list
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }

    public void traverseForward() {
        Node temp = head;
        System.out.println("Doubly Linked List (Forward):");
        while (temp != null) {
            System.out.print(temp.data + "  ");
            temp = temp.next;
        }
        System.out.println("null");
    }

    public void traverseBackward() {
        Node temp = tail;
        System.out.println("Doubly Linked List (Backward):");
        while (temp != null) {
            System.out.print(temp.data + "  ");
            temp = temp.prev;
        }
        System.out.println("null");
    }
}

public class DoublyLinkedListTraversal {
    public static void main(String[] args) {
        DoublyLinkedList list = new DoublyLinkedList();

        // Insert elements into the doubly linked list
        list.insert(1);
        list.insert(2);
        list.insert(3);
        list.insert(4);
        list.insert(5);

        // Traverse the doubly linked list in forward direction
        list.traverseForward();

        // Traverse the doubly linked list in backward direction
        list.traverseBackward();
    }
}

