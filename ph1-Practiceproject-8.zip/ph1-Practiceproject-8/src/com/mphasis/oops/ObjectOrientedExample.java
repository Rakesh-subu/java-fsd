package com.mphasis.oops;

//Encapsulation: Using private access modifiers to encapsulate data and providing public methods to access it.
class Student {
 private String name;
 private int age;

 public void setName(String n) {
     name = n;
 }

 public String getName() {
     return name;
 }

 public void setAge(int a) {
     if (a >= 0) {
         age = a;
     }
 }

 public int getAge() {
     return age;
 }
}

//Inheritance: Creating a subclass "UndergraduateStudent" that inherits from the superclass "Student".
class UndergraduateStudent extends Student {
 private String major;

 public void setMajor(String m) {
     major = m;
 }

 public String getMajor() {
     return major;
 }
}

//Polymorphism: Using polymorphism to process different types of students in a generic way.
class StudentProcessor {
 public void processStudent(Student student) {
     System.out.println("Name: " + student.getName());
     System.out.println("Age: " + student.getAge());
 }
}

//Abstraction: Using abstraction to create an interface.
interface Shape {
 double calculateArea();
}

class Circle implements Shape {
 private double radius;

 public Circle(double radius) {
     this.radius = radius;
 }

 @Override
 public double calculateArea() {
     return Math.PI * radius * radius;
 }
}

public class ObjectOrientedExample {
 public static void main(String[] args) {
     // Creating objects of Student and UndergraduateStudent classes
     Student student1 = new Student();
     student1.setName("Alice");
     student1.setAge(20);

     UndergraduateStudent student2 = new UndergraduateStudent();
     student2.setName("Bob");
     student2.setAge(22);
     student2.setMajor("Computer Science");

     // Using polymorphism to process different types of students
     StudentProcessor processor = new StudentProcessor();
     processor.processStudent(student1);
     processor.processStudent(student2);

     // Using abstraction to create objects of subclasses (Circle)
     Shape circle = new Circle(5);
     System.out.println("Area of the circle: " + circle.calculateArea());
 }
}
