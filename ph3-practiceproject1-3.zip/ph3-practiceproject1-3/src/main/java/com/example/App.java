package com.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.dao.StudentDao;
import com.example.pojo.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "my program started....." );
        
        ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
        
        
        
       StudentDao studentdao=ac.getBean(StudentDao.class);
       Student student=new Student();
       student.setId(13);
       student.setName("alok");
       student.setCity("cuttack");
       int result=studentdao.insert(student);
       System.out.println("number of records inserted"+result);
    }
}
