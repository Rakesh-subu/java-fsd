package com.example.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.example.pojo.Student;

public class StudentDAOimpl implements StudentDao {
private JdbcTemplate jdbcTemplate;
	@Override
	public int insert(Student student) {
		// TODO Auto-generated method stub
		String q="insert into student(id,name,city) values(?,?,?)";
		int r=this.jdbcTemplate.update(q,student.getId(),student.getName(),student.getCity());
		return r;
	}
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	

}
