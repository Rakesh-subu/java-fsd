package com.example.dao;

import com.example.pojo.Student;

public interface StudentDao {
	public int insert(Student student); 
		
	

}
