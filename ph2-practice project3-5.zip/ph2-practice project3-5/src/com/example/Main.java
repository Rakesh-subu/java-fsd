package com.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
    public static void main(String[] args) {
        // Create a Hibernate configuration
        Configuration configuration = new Configuration().configure("hibernate.cfg.xml");

        // Build the SessionFactory
        try (SessionFactory sessionFactory = configuration.buildSessionFactory()) {
            // Open a session
            try (Session session = sessionFactory.openSession()) {
                // Begin a transaction
                Transaction transaction = session.beginTransaction();

                // Create a Person
                Person person = new Person();
                person.setName("John Doe");

                // Add addresses to the collections
                Address homeAddress = new Address();
                homeAddress.setStreet("123 Main St");
                homeAddress.setCity("City");
                homeAddress.setZipCode("12345");

                person.getAddressesList().add(homeAddress);
                person.getAddressesSet().add(homeAddress);
                person.getAddressesBag().add(homeAddress);
                person.getAddressesMap().put("home", homeAddress);

                // Save the Person to the database
                session.save(person);

                // Commit the transaction
                transaction.commit();

                // Retrieve the Person and print their addresses
                Person retrievedPerson = session.get(Person.class, person.getId());
                System.out.println("List of addresses: " + retrievedPerson.getAddressesList());
                System.out.println("Set of addresses: " + retrievedPerson.getAddressesSet());
                System.out.println("Bag of addresses: " + retrievedPerson.getAddressesBag());
                System.out.println("Map of addresses: " + retrievedPerson.getAddressesMap());
            }
        }
    }
}
