package com.example;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Person {
	  private int id;
	    private String name;
	    private List<Address> addressesList = new ArrayList<>();
	    private Set<Address> addressesSet = new HashSet<>();
	    private List<Address> addressesBag = new ArrayList<>();
	    private Map<String, Address> addressesMap = new HashMap<>();

		public Person(int id, String name, List<Address> addressesList, Set<Address> addressesSet,
				List<Address> addressesBag, Map<String, Address> addressesMap) {
			super();
			this.id = id;
			this.name = name;
			this.addressesList = addressesList;
			this.addressesSet = addressesSet;
			this.addressesBag = addressesBag;
			this.addressesMap = addressesMap;
		}

		public Person() {
			super();
		}

		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public List<Address> getAddressesList() {
			return addressesList;
		}
		public void setAddressesList(List<Address> addressesList) {
			this.addressesList = addressesList;
		}
		public Set<Address> getAddressesSet() {
			return addressesSet;
		}
		public void setAddressesSet(Set<Address> addressesSet) {
			this.addressesSet = addressesSet;
		}
		public Map<String, Address> getAddressesMap() {
			return addressesMap;
		}
		public void setAddressesMap(Map<String, Address> addressesMap) {
			this.addressesMap = addressesMap;
		}

		public List<Address> getAddressesBag() {
			return addressesBag;
		}

		public void setAddressesBag(List<Address> addressesBag) {
			this.addressesBag = addressesBag;
		}

		
		

}
