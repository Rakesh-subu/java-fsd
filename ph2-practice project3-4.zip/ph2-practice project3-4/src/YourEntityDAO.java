import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;


public class YourEntityDAO {
	private SessionFactory sessionFactory;
	public YourEntityDAO() {
		  Configuration configuration = new Configuration();
		  configuration.addAnnotatedClass(YourEntity.class);

		  configuration.configure("hibernate.cfg.xml");
		  ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
		  sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		}

	  public void save(YourEntity entity) {
	    Session session = sessionFactory.openSession();
	    Transaction transaction = session.beginTransaction();
	    session.save(entity);
	    transaction.commit();
	    session.close();
	  }
	  public YourEntity findById(Long id) {
		    Session session = sessionFactory.openSession();
		    YourEntity entity = session.get(YourEntity.class, id);
		    session.close();
		    return entity;
		  }

}
