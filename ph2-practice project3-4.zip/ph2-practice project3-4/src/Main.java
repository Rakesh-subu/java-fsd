
public class Main {
	
		 public static void main(String[] args) {
			    YourEntityDAO dao = new YourEntityDAO();

			    YourEntity entity = new YourEntity();
			    entity.setName("John Doe");
			    dao.save(entity);

			    YourEntity savedEntity = dao.findById(entity.getId());
			    System.out.println("Saved entity: " + savedEntity);
			  }
			}

