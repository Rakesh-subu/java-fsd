package com.mphasis.fourth;

import java.util.Arrays;

public class FourthSmallestElement {
    public static void main(String[] args) {
        int[] unsortedList = {9, 4, 7, 1, 3, 6, 8, 2, 5}; // Sample unsorted list

        // Sort the list
        Arrays.sort(unsortedList);

        // Find the fourth smallest element
        int fourthSmallest = unsortedList[3];

        System.out.println("Original Unsorted List: " + Arrays.toString(unsortedList));
        System.out.println("Fourth Smallest Element: " + fourthSmallest);
    }
}
