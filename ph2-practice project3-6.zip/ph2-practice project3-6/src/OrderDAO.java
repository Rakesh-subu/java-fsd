import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class OrderDAO {
	

    private SessionFactory sessionFactory;
    public OrderDAO() {
        // Initialize the session factory
        this.sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
    }
    public OrderEntity findById(Long id) {
        Session session = sessionFactory.openSession();
        OrderEntity order = session.get(OrderEntity.class, id);

        if (order != null) {
            // Eagerly fetch the associated OrderItem entities
            order.getOrderItems().size(); // This line forces the fetching of OrderItems

            // Debug information
            System.out.println("Found Order with id: " + order.getId());
        } else {
            // Debug information
            System.out.println("Order with id " + id + " not found.");
        }

        session.close();
        return order;
    }
}