
public class Main {

   public static void main(String[] args) {
    OrderDAO dao = new OrderDAO();

    OrderEntity order = dao.findById(1L);
    System.out.println("Order id: " + order.getId());
    System.out.println("Order items:");
    for (OrderItem orderItem : order.getOrderItems()) {
        System.out.println("    - " + orderItem.getName() + " (" + orderItem.getPrice() + ")");
    }
   }
}
