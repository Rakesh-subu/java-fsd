package com.map.exp;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapsExample {
    public static void main(String[] args) {
        // HashMap Example (unordered)
        Map<String, Integer> hashMap = new HashMap<>();
        hashMap.put("One", 1);
        hashMap.put("Three", 3);
        hashMap.put("Two", 2);
        System.out.println("HashMap Elements: " + hashMap);

        // LinkedHashMap Example (keeps insertion order)
        Map<String, Integer> linkedHashMap = new LinkedHashMap<>();
        linkedHashMap.put("One", 1);
        linkedHashMap.put("Three", 3);
        linkedHashMap.put("Two", 2);
        System.out.println("LinkedHashMap Elements: " + linkedHashMap);

        // TreeMap Example (sorted by keys)
        Map<String, Integer> treeMap = new TreeMap<>();
        treeMap.put("One", 1);
        treeMap.put("Three", 3);
        treeMap.put("Two", 2);
        System.out.println("TreeMap Elements: " + treeMap);

        // Hashtable Example (synchronized, thread-safe)
        Hashtable<String, Integer> hashtable = new Hashtable<>();
        hashtable.put("One", 1);
        hashtable.put("Three", 3);
        hashtable.put("Two", 2);
        System.out.println("Hashtable Elements: " + hashtable);

        // Accessing elements from HashMap
        System.out.println("Value for key 'Two' in HashMap: " + hashMap.get("Two"));

        // Removing elements from LinkedHashMap
        linkedHashMap.remove("One");
        System.out.println("LinkedHashMap after removing key 'One': " + linkedHashMap);

        // Checking if keys exist in TreeMap and Hashtable
        System.out.println("Does TreeMap contain key 'Three'? " + treeMap.containsKey("Three"));
        System.out.println("Does Hashtable contain key 'Four'? " + hashtable.containsKey("Four"));

        // Iterating over Hashtable
        System.out.println("Iterating over Hashtable:");
        for (Map.Entry<String, Integer> entry : hashtable.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

}
