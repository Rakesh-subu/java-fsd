package com.mphasis.main;

import java.sql.SQLException;

import com.mphasis.dao.UsersDAO;

public class Main {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        UsersDAO userDAO = new UsersDAO();
        userDAO.addUser(6,"prasant");
        
    }
}
