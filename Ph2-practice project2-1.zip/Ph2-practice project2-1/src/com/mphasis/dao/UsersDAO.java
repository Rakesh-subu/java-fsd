package com.mphasis.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.mphasis.dbutil.DbUtil;

public class UsersDAO {
    public void addUser(int id,String name) throws ClassNotFoundException, SQLException {
        String query = "INSERT INTO users (id,name) VALUES (?,?)";

        Connection connection =DbUtil.dbcon();
             PreparedStatement preparedStatement = connection.prepareStatement(query) ;
            preparedStatement.setInt(1, id);
            preparedStatement.setString(2, name);
            preparedStatement.executeUpdate();
            System.out.println("User added successfully.");
        } 
        }
    

