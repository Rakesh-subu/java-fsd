package com.impicitexplicit.exp;

public class ImplicitExplicitCasting {
	public static void main(String args[])
    {
        System.out.println("Implicit type casting:");
        int a=10;
        double b=a;
        System.out.println("value of b is:"+b);
        System.out.println("explicit type casting:");
        double p=23;
        int q= (int) p;
        System.out.println("value of q is:"+q);


    }

}
