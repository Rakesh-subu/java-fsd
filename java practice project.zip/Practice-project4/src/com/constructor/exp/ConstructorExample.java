package com.constructor.exp;

public class ConstructorExample {
	


    // Default constructor (no parameters)
    ConstructorExample() {
        System.out.println("Default Constructor");
    }

    // Parameterized constructor with one parameter
    ConstructorExample(int num) {
        System.out.println("Parameterized Constructor with one parameter: " + num);
    }

    // Parameterized constructor with two parameters
    ConstructorExample(int num1, int num2) {
        System.out.println("Parameterized Constructor with two parameters: " + num1 + ", " + num2);
    }


    public static void main(String[] args) {
        // Creating objects using different constructors
        ConstructorExample obj1 = new ConstructorExample(); // Calls the default constructor
        ConstructorExample obj2 = new ConstructorExample(10); // Calls the parameterized constructor with one parameter
        ConstructorExample obj3 = new ConstructorExample(50, 60); // Calls the parameterized constructor with two parameters
    }

}
