package com.string.exp;

public class StringConversion {

	  public static void main(String[] args) {
	        // Create a string
	        String str = "Hello, World!";
	        System.out.println("Original String: " + str);

	        // Convert string to StringBuffer
	        StringBuffer stringBuffer = new StringBuffer(str);
	        System.out.println("StringBuffer: " + stringBuffer);

	        // Convert string to StringBuilder
	        StringBuilder stringBuilder = new StringBuilder(str);
	        System.out.println("StringBuilder: " + stringBuilder);
	    }
}
