package com.implement.exp;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpressionVerifier {
	   public static void main(String[] args) {
	        // Define an array of regular expressions to be tested
	        String[] regexPatterns = {
	            "[a-zA-Z]+",          // Matches one or more letters
	            "\\d{3}",             // Matches exactly three digits
	            "\\b\\d+\\b",         // Matches whole numbers (positive or negative)
	            "\\b\\d+\\.\\d+\\b",  // Matches decimal numbers
	            "[a-zA-Z]{5,10}"      // Matches between 5 to 10 letters
	        };

	        // Input strings to test against the regular expressions
	        String[] testStrings = {
	            "Hello",
	            "123",
	            "42",
	            "3.14",
	            "Java"
	        };

	        // Verify the regular expressions against the input strings
	        for (String regex : regexPatterns) {
	            System.out.println("Regular Expression: " + regex);
	            Pattern pattern = Pattern.compile(regex);
	            for (String input : testStrings) {
	                Matcher matcher = pattern.matcher(input);
	                boolean matches = matcher.matches();
	                System.out.println("Input: " + input + " - Matches: " + matches);
	            }
	            System.out.println("---------------------------");
	        }
	    }
}
