package com.collection.exp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CollectionExample {

    public static void main(String[] args) {
        // ArrayList Example
        List<String> arrayList = new ArrayList<>();
        arrayList.add("Apple");
        arrayList.add("Banana");
        arrayList.add("Orange");
        System.out.println("ArrayList Elements: " + arrayList);

        // HashSet Example
        Set<Integer> hashSet = new HashSet<>();
        hashSet.add(10);
        hashSet.add(20);
        hashSet.add(30);
        System.out.println("HashSet Elements: " + hashSet);

        // HashMap Example
        Map<String, Integer> hashMap = new HashMap<>();
        hashMap.put("One", 1);
        hashMap.put("Two", 2);
        hashMap.put("Three", 3);
        System.out.println("HashMap Elements: " + hashMap);

        // Accessing elements from ArrayList
        System.out.println("Element at index 1 in ArrayList: " + arrayList.get(1));

        // Checking if HashSet contains a specific element
        System.out.println("HashSet contains 20: " + hashSet.contains(20));

        // Getting value from HashMap using key
        System.out.println("Value for key 'Two' in HashMap: " + hashMap.get("Two"));

        // Iterating over ArrayList
        System.out.println("Iterating over ArrayList:");
        for (String fruit : arrayList) {
            System.out.println(fruit);
        }

        // Iterating over HashSet
        System.out.println("Iterating over HashSet:");
        for (int num : hashSet) {
            System.out.println(num);
        }

        // Iterating over HashMap
        System.out.println("Iterating over HashMap:");
        for (Map.Entry<String, Integer> entry : hashMap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

}
