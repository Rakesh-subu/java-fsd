package com.example;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

public class NestedCases {
	@Nested
	@DisplayName("Addition Tests")
	class AdditionTests{
		@Test
		@DisplayName("Test Positive Number")
		void testAddPositiveNumbers()
		{
			Calculator calculator=new Calculator();
			assertEquals(5,calculator.add(3, 2));
		}
		@Test
		@DisplayName("Test negative numbers")
		void testAddNegativeNumbers() {
			Calculator calculator = new Calculator();
			assertEquals(-1, calculator.add(2, -3));
		}
	}
		  @Nested
		    @DisplayName("Subtraction Tests")
		    class SubtractionTests {

		        @Test
		        @DisplayName("Test positive numbers")
		        void testSubtractPositiveNumbers() {
		            Calculator calculator = new Calculator();
		            assertEquals(1, calculator.subtract(3, 2));
		        }

		        @Test
		        @DisplayName("Test negative numbers")
		        void testSubtractNegativeNumbers() {
		            Calculator calculator = new Calculator();
		            assertEquals(-5, calculator.subtract(-2, 3));
		        }
		    
	}
	
}


