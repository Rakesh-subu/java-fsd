package com.example;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;

public class RepeatedTests {

    @RepeatedTest(5)
    @DisplayName("Repeated Addition Test")
    void testRepeatedAddition() {
        Calculator calculator = new Calculator();
        assertEquals(5, calculator.add(3, 2));
    }

    @RepeatedTest(3)
    @DisplayName("Repeated Subtraction Test")
    void testRepeatedSubtraction() {
        Calculator calculator = new Calculator();
        assertEquals(1, calculator.subtract(3, 2));
    }
}
