package com.example;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

@TestInstance(Lifecycle.PER_CLASS)
public class DependencyInjection {

    private Calculator calculator;

    // Constructor injection for Calculator
    public DependencyInjection() {
        this.calculator = new Calculator();
    }

    @Test
    void testAddition() {
        assertEquals(5, calculator.add(3, 2));
    }

    @Test
    void testSubtraction() {
        assertEquals(1, calculator.subtract(3, 2));
    }

    
}
