package com.example.demo;

public class ProductNotFoundException extends RuntimeException{

}