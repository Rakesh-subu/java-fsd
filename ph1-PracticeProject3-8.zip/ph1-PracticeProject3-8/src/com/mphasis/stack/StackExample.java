package com.mphasis.stack;

class Stack {
    private int maxSize;
    private int[] stackArray;
    private int top;

    public Stack(int size) {
        maxSize = size;
        stackArray = new int[maxSize];
        top = -1;
    }

    public void push(int value) {
        if (top < maxSize - 1) {
            stackArray[++top] = value;
            System.out.println("Pushed: " + value);
        } else {
            System.out.println("Stack is full. Cannot push " + value);
        }
    }

    public void pop() {
        if (top >= 0) {
            int poppedValue = stackArray[top--];
            System.out.println("Popped: " + poppedValue);
        } else {
            System.out.println("Stack is empty. Cannot pop.");
        }
    }

    public boolean isEmpty() {
        return top == -1;
    }
}

public class StackExample {
    public static void main(String[] args) {
        Stack stack = new Stack(6); // Creating a stack with a maximum size of 5

        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);
        stack.push(5);
        stack.push(6); // Attempting to push an element into a full stack

        while (!stack.isEmpty()) {
            stack.pop();
        }

        stack.pop(); // Attempting to pop from an empty stack
    }
}
