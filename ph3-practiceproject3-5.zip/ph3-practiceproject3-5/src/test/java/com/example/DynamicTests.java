package com.example;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

import java.util.stream.Stream;

public class DynamicTests {

    @TestFactory
    Stream<DynamicTest> testDynamicAddition() {
        return Stream.of(
                DynamicTest.dynamicTest("Addition Test 1", () -> {
                    Calculator calculator = new Calculator();
                    assertEquals(5, calculator.add(3, 2));
                }),
                DynamicTest.dynamicTest("Addition Test 2", () -> {
                    Calculator calculator = new Calculator();
                    assertEquals(10, calculator.add(7, 3));
                })
        );
    }

}
