public class Main {
    public static void main(String[] args) {
        DatabaseOperations databaseOperations = new DatabaseOperations();
        databaseOperations.insertUser(4, "alok");
 
    }
}
