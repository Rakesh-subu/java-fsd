package com.mphasis.merge;

public class MergeSort {
    public static void merge(int[] A, int start, int mid, int end) {
        int p = start, q = mid + 1;
        int[] Arr = new int[end - start + 1];
        int k = 0;

        for (int i = start; i <= end; i++) {
            if (p > mid)
                Arr[k++] = A[q++];
            else if (q > end)
                Arr[k++] = A[p++];
            else if (A[p] < A[q])
                Arr[k++] = A[p++];
            else
                Arr[k++] = A[q++];
        }

        for (int i = 0; i < k; i++) {
            A[start++] = Arr[i];
        }
    }

    public static void mergeSort(int[] A, int start, int end) {
        if (start < end) {
            int mid = (start + end) / 2;
            mergeSort(A, start, mid);
            mergeSort(A, mid + 1, end);
            merge(A, start, mid, end);
        }
    }

    public static void main(String[] args) {
        int[] A = {38, 27, 43, 3, 9, 82, 10};
        int n = A.length;

        System.out.print("Original Array: ");
        for (int num : A) {
            System.out.print(num + " ");
        }
        System.out.println();

        mergeSort(A, 0, n - 1);

        System.out.print("Sorted Array: ");
        for (int num : A) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
