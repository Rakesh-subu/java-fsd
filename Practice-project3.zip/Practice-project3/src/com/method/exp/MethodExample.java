package com.method.exp;

public class MethodExample {
	
	 // Method without parameters and return value
    public void printHello() {
        System.out.println("Hello, World!");
    }

    // Method with parameters and return value
    public int addNumbers(int a, int b) {
        return a + b;
    }

    // Static method
    public static void staticMethod() {
        System.out.println("This is a static method.");
    }

    // Main method
    public static void main(String[] args) {
        MethodExample obj = new MethodExample();

        // Calling a method without parameters and return value
        obj.printHello();

        // Calling a method with parameters and return value
        int sum = obj.addNumbers(5, 10);
        System.out.println("Sum of 5 and 10 is: " + sum);

        // Calling a static method using class name
        MethodExample.staticMethod();

        // Another way to call a static method (recommended)
        staticMethod();
    }

}
