package com.mphasis.file;

import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

public class FileOperationsExample {
    public static void main(String[] args) throws IOException {
        // Create a new file and write content to it
        File file = new File("example.txt");
        FileWriter writer = new FileWriter(file);
        writer.write("Hello, this is a file example.\n");
        writer.close();

        // Read content from the file
        BufferedReader reader = new BufferedReader(new FileReader(file));
        System.out.println("Content of the file:");
        String line;
        while ((line = reader.readLine()) != null) {
            System.out.println(line);
        }
        reader.close();

        // Update the file (append more content)
        FileWriter appendWriter = new FileWriter(file, true);
        appendWriter.write("Appending more content to the file.\n");
        appendWriter.close();

        // Read updated content from the file
        BufferedReader updatedReader = new BufferedReader(new FileReader(file));
        System.out.println("Updated content of the file:");
        String updatedLine;
        while ((updatedLine = updatedReader.readLine()) != null) {
            System.out.println(updatedLine);
        }
        updatedReader.close();

        // Delete the file
        if (file.delete()) {
            System.out.println("File deleted successfully.");
        } else {
            System.out.println("Failed to delete the file.");
        }
    }
}

