package com.example;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class AssertionsTest {

    @Test
    @DisplayName("Test Equality")
    void testEquality() {
        assertEquals(42, 40 + 2);
    }

    @Test
    @DisplayName("Test Truthiness")
    void testTruthiness() {
        assertTrue(5 > 3);
    }

    @Test
    @DisplayName("Test Nullability")
    void testNullability() {
        assertNull(null);
    }

   
}
